#!/usr/bin/env python3
"""
TEMPO Explorer — Server
=======================
Serves NASA TEMPO (and TROPOMI) air quality granules as quantized JSON grids
for client-side canvas rendering. No matplotlib required.

Usage:
    pip install earthaccess xarray netCDF4 h5netcdf h5py numpy
    python server.py

Then open http://localhost:8765
"""

import json
import math
import threading
import traceback
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import numpy as np

try:
    import earthaccess
    HAS_EARTHACCESS = True
except ImportError:
    earthaccess = None
    HAS_EARTHACCESS = False

try:
    import xarray as xr
    HAS_XARRAY = True
except ImportError:
    xr = None
    HAS_XARRAY = False

PORT = 8765
NAN_SENTINEL = 65535
MAX_UINT16    = 65534
MAX_GRID_PIXELS = 900 * 450   # downsample server-side to keep JSON payload manageable

# ─── Product registry ─────────────────────────────────────────────────────────

PRODUCTS = {
    "NO2": {
        "short_names": ["TEMPO_NO2_L3", "TEMPO_NO2_L2"],
        "var":         "vertical_column_troposphere",
        "qa_var":      "main_data_quality_flag",
        "unit":        "molec/cm²",
        "label":       "NO₂ Tropospheric VCD",
        "cmap":        "plasma",
    },
    "HCHO": {
        "short_names": ["TEMPO_HCHO_L3", "TEMPO_HCHO_L2"],
        "var":         "vertical_column",
        "qa_var":      "main_data_quality_flag",
        "unit":        "molec/cm²",
        "label":       "HCHO Total Column",
        "cmap":        "YlOrRd",
    },
    "O3": {
        "short_names": ["TEMPO_O3TOT_L3"],
        "var":         "column_amount",
        "unit":        "DU",
        "label":       "O₃ Total Column",
        "cmap":        "RdBu_r",
    },
}

# Try versions newest-first; also fall back to no version filter
VERSIONS = ["V03", "V04", "V02", "V01"]

# ─── Global state ─────────────────────────────────────────────────────────────

_auth           = None
_frame_cache    = {}   # key → {data, lons, lats, ts, unit, label, cmap, vmin, vmax, valid_frac}
_build_progress = {"status": "idle", "pct": 0, "msg": "", "frames": [], "error": ""}


# ─── Auth ─────────────────────────────────────────────────────────────────────

def ensure_auth():
    global _auth
    if _auth is None and HAS_EARTHACCESS:
        try:
            _auth = earthaccess.login(strategy="netrc")
            print("[auth] Logged in via ~/.netrc")
        except Exception:
            try:
                _auth = earthaccess.login(strategy="interactive", persist=True)
            except Exception as e:
                print(f"[auth] Login failed: {e}")
    return _auth


# ─── Quantisation ─────────────────────────────────────────────────────────────

def quantize(data: np.ndarray, vmin: float, vmax: float) -> np.ndarray:
    """Map float64 → uint16.  65535 = NaN sentinel, 0-65534 = valid range."""
    out   = np.full(data.shape, NAN_SENTINEL, dtype=np.uint16)
    valid = np.isfinite(data)
    if valid.any():
        span  = max(vmax - vmin, 1e-30)
        norm  = np.clip((data[valid] - vmin) / span, 0.0, 1.0)
        out[valid] = (norm * MAX_UINT16).astype(np.uint16)
    return out


def stride_downsample(arr2d: np.ndarray, max_pixels: int):
    """Return (downsampled_array, stride) using simple striding."""
    if arr2d.size <= max_pixels:
        return arr2d, 1
    stride = max(1, int(math.ceil(math.sqrt(arr2d.size / max_pixels))))
    return arr2d[::stride, ::stride], stride


# ─── Granule helpers ─────────────────────────────────────────────────────────

def granule_ts(gran) -> str:
    """Return the beginning datetime string for a DataGranule."""
    try:
        return gran['umm']['TemporalExtent']['RangeDateTime']['BeginningDateTime']
    except (KeyError, TypeError):
        pass
    # Fallback: try legacy attribute
    ts = getattr(gran, 'time_start', None)
    if ts:
        return str(ts)
    return 'unknown'


# ─── Granule search ───────────────────────────────────────────────────────────

def search_granules(short_name: str, start_dt: str, end_dt: str, bbox: list):
    """Search earthaccess trying multiple versions; return granule list."""
    for version in VERSIONS:
        try:
            results = earthaccess.search_data(
                short_name=short_name,
                version=version,
                temporal=(start_dt, end_dt),
                bounding_box=tuple(bbox),
                count=50,
            )
            if results:
                print(f"[search] {short_name} {version}: {len(results)} granule(s)")
                return results
        except Exception as e:
            print(f"[search] {short_name} {version}: {e}")

    # Last resort — no version filter
    try:
        results = earthaccess.search_data(
            short_name=short_name,
            temporal=(start_dt, end_dt),
            bounding_box=tuple(bbox),
            count=50,
        )
        if results:
            print(f"[search] {short_name} (any version): {len(results)} granule(s)")
            return results
    except Exception as e:
        print(f"[search] {short_name} (any version): {e}")

    return []


# ─── Frame extraction ─────────────────────────────────────────────────────────

def extract_frame(gran, prod_cfg: dict, bbox: list, qa_filter: bool):
    """
    Open one granule, extract the data variable + coordinates.
    Returns a dict with keys: data, lons, lats, ts, unit, label, cmap, valid_frac
    or None on failure.
    Data is normalised so that:
      - lats increase from row 0 to row -1  (south → north)
      - lons increase from col 0 to col -1  (west → east)
      - fill values → NaN
    """
    ts      = granule_ts(gran)
    fh_list = earthaccess.open([gran])
    if not fh_list:
        return None

    fh = fh_list[0]          # EarthAccessFile — has seek/read/close but no __enter__
    try:
        # ── Open product group (L3 data lives here) ───────────────────────
        ds = None
        for group in ("product", None):
            try:
                fh.seek(0)
                ds = xr.open_dataset(fh, group=group, engine="h5netcdf",
                                     mask_and_scale=True)
                break
            except Exception:
                pass
        if ds is None:
            return None

        # ── Find data variable ────────────────────────────────────────────
        var_name = prod_cfg["var"]
        if var_name not in ds:
            candidates = [v for v in ds.data_vars
                          if any(k in v.lower() for k in ("column", "amount", "fraction"))]
            if not candidates:
                print(f"  [extract] var '{var_name}' not found; available: {list(ds.data_vars)}")
                return None
            var_name = candidates[0]
            print(f"  [extract] using fallback var: {var_name}")

        col = ds[var_name]

        # ── QA filter ─────────────────────────────────────────────────────
        qa_var = prod_cfg.get("qa_var", "")
        if qa_filter and qa_var and qa_var in ds:
            col = col.where(ds[qa_var] == 0)

        # ── Coordinates — for L3 these are in the root group ─────────────
        lons_1d = lats_1d = None

        # 1. Try root dataset (TEMPO L3 pattern: coords are root-level)
        try:
            fh.seek(0)
            ds_root = xr.open_dataset(fh, engine="h5netcdf")
            for lon_key, lat_key in (("longitude", "latitude"), ("lon", "lat")):
                if lon_key in ds_root.coords or lon_key in ds_root:
                    src = ds_root.coords if lon_key in ds_root.coords else ds_root
                    lons_1d = src[lon_key].values.ravel()
                    lats_1d = src[lat_key].values.ravel()
                    break
        except Exception:
            pass

        # 2. Fallback: coordinate dims of the data variable
        if lons_1d is None:
            for lon_key, lat_key in (("longitude", "latitude"), ("lon", "lat")):
                if lon_key in col.coords:
                    lons_1d = col.coords[lon_key].values.ravel()
                    lats_1d = col.coords[lat_key].values.ravel()
                    break

        # 3. Fallback: coords / data_vars in the product group
        if lons_1d is None:
            for lon_key, lat_key in (("longitude", "latitude"), ("lon", "lat")):
                src = ds.coords if lon_key in ds.coords else ds
                if lon_key in src:
                    lons_1d = src[lon_key].values.ravel()
                    lats_1d = src[lat_key].values.ravel()
                    break

        if lons_1d is None:
            print("  [extract] could not find coordinates")
            return None

        # ── Data array ────────────────────────────────────────────────────
        data = col.values
        # Squeeze leading time/singleton dims
        while data.ndim > 2 and data.shape[0] == 1:
            data = data[0]
        if data.ndim != 2:
            print(f"  [extract] unexpected data shape after squeeze: {data.shape}")
            return None

        data = data.astype(np.float64)
        data[~np.isfinite(data)] = np.nan
        data[np.abs(data) > 1e29] = np.nan

        # ── Crop to bbox and build 2D coordinate arrays ───────────────────
        nrow, ncol = data.shape
        if lons_1d.shape[0] == ncol and lats_1d.shape[0] == nrow:
            # Regular L3 grid: 1D lon (ncol) × 1D lat (nrow)
            lon_mask = (lons_1d >= bbox[0]) & (lons_1d <= bbox[2])
            lat_mask = (lats_1d >= bbox[1]) & (lats_1d <= bbox[3])
            if lon_mask.any() and lat_mask.any():
                data    = data[np.ix_(lat_mask, lon_mask)]
                lons_1d = lons_1d[lon_mask]
                lats_1d = lats_1d[lat_mask]
            lons_2d, lats_2d = np.meshgrid(lons_1d, lats_1d)
        elif lons_1d.size == data.size:
            # Swath / 2D coordinates
            lons_2d = lons_1d.reshape(data.shape)
            lats_2d = lats_1d.reshape(data.shape)
            mask    = ((lons_2d >= bbox[0]) & (lons_2d <= bbox[2]) &
                       (lats_2d >= bbox[1]) & (lats_2d <= bbox[3]))
            data[~mask] = np.nan
        else:
            # Last resort: meshgrid raw arrays
            lons_2d, lats_2d = np.meshgrid(lons_1d, lats_1d)

        # ── Normalise orientation: row 0 = south, col 0 = west ───────────
        if lats_2d[0, 0] > lats_2d[-1, 0]:
            data    = data[::-1,    :]
            lats_2d = lats_2d[::-1, :]
            lons_2d = lons_2d[::-1, :]
        if lons_2d[0, 0] > lons_2d[0, -1]:
            data    = data[:,    ::-1]
            lats_2d = lats_2d[:, ::-1]
            lons_2d = lons_2d[:, ::-1]

        finite     = np.isfinite(data)
        valid_frac = float(finite.sum()) / max(data.size, 1)
        print(f"  [extract] shape={data.shape}, valid={finite.sum()}/{data.size} "
              f"({valid_frac*100:.1f}%)")

        return {
            "data":       data,
            "lons":       lons_2d,
            "lats":       lats_2d,
            "ts":         ts,
            "unit":       prod_cfg["unit"],
            "label":      prod_cfg["label"],
            "cmap":       prod_cfg["cmap"],
            "valid_frac": valid_frac,
        }

    finally:
        try:
            fh.close()
        except Exception:
            pass


# ─── Background fetch ─────────────────────────────────────────────────────────

def background_fetch(product: str, start_dt: str, end_dt: str,
                     bbox: list, qa_filter: bool = True):
    global _build_progress, _frame_cache

    _build_progress = {"status": "running", "pct": 0,
                       "msg": "Authenticating…", "frames": [], "error": ""}
    _frame_cache    = {}

    try:
        ensure_auth()

        prod_cfg = PRODUCTS.get(product)
        if not prod_cfg:
            raise ValueError(f"Unknown product: {product}")

        # Search granules across candidate short-names (L3 first, L2 fallback)
        _build_progress["msg"] = f"Searching for {product} granules…"
        _build_progress["pct"] = 5

        granules = []
        for short_name in prod_cfg["short_names"]:
            granules = search_granules(short_name, start_dt, end_dt, bbox)
            if granules:
                break

        if not granules:
            _build_progress.update(status="done", pct=100,
                                   msg="No granules found for the specified parameters.")
            return

        print(f"[fetch] {len(granules)} granule(s) to process")
        frames = []

        for i, gran in enumerate(granules):
            ts  = granule_ts(gran)
            pct = 5 + int(i / len(granules) * 90)
            _build_progress["pct"] = pct
            _build_progress["msg"] = f"[{i+1}/{len(granules)}] {ts[:16]} UTC…"

            try:
                print(f"[fetch] [{i+1}/{len(granules)}] {ts[:16]}")
                frame = extract_frame(gran, prod_cfg, bbox, qa_filter)
                if frame is None:
                    frames.append({"key": f"err_{i}", "ts": ts, "ok": False,
                                   "error": "No valid data extracted"})
                    continue

                key               = f"{product}_{ts}_{i}"
                _frame_cache[key] = frame
                frames.append({
                    "key":        key,
                    "ts":         ts,
                    "ok":         True,
                    "valid_frac": round(frame["valid_frac"] * 100, 1),
                    "product":    product,
                })
                print(f"[fetch] ✓ cached as {key}")

            except Exception as e:
                print(f"[fetch] ✗ {ts[:16]}: {e}")
                traceback.print_exc()
                frames.append({"key": f"err_{i}", "ts": ts, "ok": False, "error": str(e)})

        # Compute global vmin/vmax (p2/p98) across all valid frames
        all_vals = []
        for f in frames:
            if f["ok"] and f["key"] in _frame_cache:
                v = _frame_cache[f["key"]]["data"]
                fin = v[np.isfinite(v)]
                if len(fin):
                    all_vals.append(fin)

        if all_vals:
            combined = np.concatenate(all_vals)
            vmin     = float(np.percentile(combined, 2))
            vmax     = float(np.percentile(combined, 98))
            for f in frames:
                if f["ok"] and f["key"] in _frame_cache:
                    _frame_cache[f["key"]]["vmin"] = vmin
                    _frame_cache[f["key"]]["vmax"] = vmax

        ok_count = sum(1 for f in frames if f["ok"])
        _build_progress.update(
            status="done", pct=100, frames=frames,
            msg=f"Done — {ok_count}/{len(frames)} frame(s) loaded.",
        )

    except Exception:
        _build_progress.update(
            status="error",
            error=traceback.format_exc(),
            msg="An error occurred — see server console.",
        )


# ─── HTTP handler ─────────────────────────────────────────────────────────────

class ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True


class Handler(BaseHTTPRequestHandler):

    def log_message(self, fmt, *args):
        # Suppress 200/304; show everything else
        if args and str(args[1]) not in ("200", "304"):
            print(f"[HTTP {args[1]}] {args[0]}")

    def send_json(self, obj, status=200):
        body = json.dumps(obj, default=str).encode()
        self.send_response(status)
        self.send_header("Content-Type",   "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def send_bytes(self, data, mime, status=200):
        self.send_response(status)
        self.send_header("Content-Type",   mime)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Cache-Control",  "no-cache")
        self.end_headers()
        self.wfile.write(data)

    def send_file(self, path, mime):
        with open(path, "rb") as f:
            data = f.read()
        self.send_bytes(data, mime)

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin",  "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    # ── GET ──────────────────────────────────────────────────────────────────

    def do_GET(self):
        parsed = urlparse(self.path)
        path   = parsed.path
        params = parse_qs(parsed.query)

        # Frontend
        if path in ("/", "/index.html"):
            self.send_file(Path(__file__).parent / "index.html",
                           "text/html; charset=utf-8")
            return

        # Dependency / capability check
        if path == "/api/check":
            self.send_json({
                "earthaccess": HAS_EARTHACCESS,
                "xarray":      HAS_XARRAY,
                "products":    list(PRODUCTS.keys()),
            })
            return

        # Build progress
        if path == "/api/progress":
            self.send_json(_build_progress)
            return

        # ── /api/frame — quantised JSON grid ─────────────────────────────
        if path == "/api/frame":
            key = params.get("key", [None])[0]
            if not key or key not in _frame_cache:
                self.send_json({"error": "Frame not found"}, 404)
                return

            fc   = _frame_cache[key]
            data = fc["data"]
            lons = fc["lons"]
            lats = fc["lats"]

            # Per-frame vmin/vmax (set during background_fetch)
            fin  = data[np.isfinite(data)]
            vmin = fc.get("vmin", float(np.percentile(fin, 2))  if len(fin) else 0.0)
            vmax = fc.get("vmax", float(np.percentile(fin, 98)) if len(fin) else 1.0)
            if vmin == vmax:
                vmax = vmin + 1.0

            # Downsample if needed so the JSON payload stays manageable
            ds_data, stride = stride_downsample(data, MAX_GRID_PIXELS)
            ds_lons = lons[::stride, ::stride]
            ds_lats = lats[::stride, ::stride]

            grid = quantize(ds_data, vmin, vmax)

            self.send_json({
                "lon_min": float(np.nanmin(ds_lons)),
                "lon_max": float(np.nanmax(ds_lons)),
                "lat_min": float(np.nanmin(ds_lats)),
                "lat_max": float(np.nanmax(ds_lats)),
                "nlon":    int(grid.shape[1]),
                "nlat":    int(grid.shape[0]),
                "grid":    grid.flatten().tolist(),
                "vmin":    vmin,
                "vmax":    vmax,
                "unit":    fc["unit"],
                "label":   fc["label"],
                "cmap":    fc["cmap"],
                "ts":      fc["ts"],
            })
            return

        # ── /api/frame_data — statistics ─────────────────────────────────
        if path == "/api/frame_data":
            key = params.get("key", [None])[0]
            if not key or key not in _frame_cache:
                self.send_json({"error": "Not found"}, 404)
                return
            fc  = _frame_cache[key]
            d   = fc["data"]
            fin = d[np.isfinite(d)]
            self.send_json({
                "ts":         fc["ts"],
                "label":      fc["label"],
                "unit":       fc["unit"],
                "valid_frac": fc.get("valid_frac", 0),
                "shape":      list(d.shape),
                "min":        float(np.nanmin(d))           if len(fin) else None,
                "max":        float(np.nanmax(d))           if len(fin) else None,
                "mean":       float(np.nanmean(d))          if len(fin) else None,
                "median":     float(np.nanmedian(fin))      if len(fin) else None,
                "std":        float(np.nanstd(fin))         if len(fin) else None,
                "p2":         float(np.percentile(fin,  2)) if len(fin) else None,
                "p25":        float(np.percentile(fin, 25)) if len(fin) else None,
                "p75":        float(np.percentile(fin, 75)) if len(fin) else None,
                "p98":        float(np.percentile(fin, 98)) if len(fin) else None,
                "vmin":       fc.get("vmin"),
                "vmax":       fc.get("vmax"),
            })
            return

        # ── /api/pixel — value at lon/lat ────────────────────────────────
        if path == "/api/pixel":
            key = params.get("key", [None])[0]
            try:
                lon = float(params.get("lon", [0])[0])
                lat = float(params.get("lat", [0])[0])
            except (ValueError, TypeError):
                self.send_json({"error": "Invalid lon/lat"}, 400)
                return
            if not key or key not in _frame_cache:
                self.send_json({"error": "Not found"}, 404)
                return
            fc    = _frame_cache[key]
            lons  = fc["lons"]
            lats  = fc["lats"]
            data  = fc["data"]
            dists = (lons - lon) ** 2 + (lats - lat) ** 2
            idx   = np.unravel_index(np.argmin(dists), dists.shape)
            val   = float(data[idx])
            self.send_json({
                "value": None if math.isnan(val) else val,
                "unit":  fc["unit"],
                "lon":   float(lons[idx]),
                "lat":   float(lats[idx]),
            })
            return

        self.send_json({"error": "Not found"}, 404)

    # ── POST ─────────────────────────────────────────────────────────────────

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        body   = json.loads(self.rfile.read(length)) if length else {}
        parsed = urlparse(self.path)

        if parsed.path == "/api/build":
            product   = body.get("product",    "NO2")
            start_dt  = body.get("start",      "2025-01-07 13:00:00")
            end_dt    = body.get("end",        "2025-01-07 21:00:00")
            bbox      = body.get("bbox",       [-130, 20, -60, 55])
            qa_filter = body.get("qa_filter",  True)

            if _build_progress["status"] == "running":
                self.send_json({"ok": False, "msg": "Already running — wait or refresh."})
                return

            t = threading.Thread(
                target=background_fetch,
                args=(product, start_dt, end_dt, bbox, qa_filter),
                daemon=True,
            )
            t.start()
            self.send_json({"ok": True, "msg": "Build started."})
            return

        self.send_json({"error": "Not found"}, 404)


# ─── Entry point ──────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    print("\n=== TEMPO Explorer ===")
    print(f"    http://localhost:{PORT}")
    print("    Ctrl+C to stop\n")
    print(f"  earthaccess : {'OK' if HAS_EARTHACCESS else 'MISSING  pip install earthaccess'}")
    print(f"  xarray      : {'OK' if HAS_XARRAY      else 'MISSING  pip install xarray h5netcdf'}")

    if not (HAS_EARTHACCESS and HAS_XARRAY):
        print("\nInstall missing packages and re-run.")
        raise SystemExit(1)

    # Bind to all interfaces so Docker port-mapping (and LAN access) works.
    # On a local dev machine this is still only reachable within your network.
    server = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)

    def _open_browser():
        import time
        time.sleep(1.2)
        webbrowser.open(f"http://localhost:{PORT}")

    threading.Thread(target=_open_browser, daemon=True).start()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n[server] Stopped.")
