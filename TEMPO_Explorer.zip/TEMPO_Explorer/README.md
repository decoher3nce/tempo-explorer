# TEMPO Explorer

A two-file local web app that visualises real NASA TEMPO satellite air quality
data (NO₂, HCHO, O₃) directly from NASA Earthdata — no external web service
required.

---

## What you need

| Requirement | Notes |
|---|---|
| Python 3.9 or later | https://www.python.org/downloads/ |
| NASA Earthdata account | Free — https://urs.earthdata.nasa.gov/users/new |
| Internet access | Data streams live from NASA on each fetch |

---

## One-time setup

### 1 — Install Python packages

Open a terminal (Command Prompt, PowerShell, or macOS Terminal) in the folder
containing these files and run:

```
pip install -r requirements.txt
```

This installs: `earthaccess`, `xarray`, `h5netcdf`, `h5py`, `numpy`

---

### 2 — Save your NASA Earthdata credentials

Create a file called `.netrc` in your **home directory**:

| OS | Home directory |
|---|---|
| Windows | `C:\Users\YOUR_USERNAME\` |
| macOS / Linux | `~/` (i.e. `/Users/YOUR_USERNAME/`) |

Paste this into the file, replacing the placeholders with your Earthdata login:

```
machine urs.earthdata.nasa.gov
login YOUR_EARTHDATA_USERNAME
password YOUR_EARTHDATA_PASSWORD
```

**Windows note** — the file must be named `.netrc` with no extension.
In Notepad choose File -> Save As, set "Save as type" to All Files, and
type `.netrc` as the filename.

**macOS / Linux note** — lock down the file permissions:
```
chmod 600 ~/.netrc
```

---

## Running the app

### 1 — Start the server

In a terminal, navigate to the folder containing `server.py` and run:

```
python server.py
```

You should see:

```
=== TEMPO Explorer ===
    http://localhost:8765
    Ctrl+C to stop

  earthaccess : OK
  xarray      : OK
```

Your browser will open automatically. If it does not, navigate to:

```
http://localhost:8765
```

### 2 — Fetch data

1. Choose a **Product** (NO2 is a good starting point)
2. Choose a **Region** (Continental US covers the test dataset)
3. Set the **Time Range** — try 2025-01-07 13:00 to 2025-01-07 21:00 UTC
   for a known-good test dataset that produces 10 frames
4. Click **Fetch Data**
5. Wait 2-4 minutes while frames download from NASA
6. Frames appear in the list on the left — click one to view it

### 3 — Controls (appear after data loads)

| Action | How |
|---|---|
| Zoom in | Drag a box on the map, or use the scroll wheel |
| Pan | Alt + drag |
| Reset view | Double-click the map |
| Read a value | Hover the mouse over the map |
| Animate | Click Play |
| Change speed | fps slider next to Play |
| Log stretch | Checkbox in the bottom controls bar |
| Opacity | Slider in the bottom controls bar |
| Export PNG | PNG button in the bottom controls bar |
| Export GIF | GIF button (takes ~30s for 10 frames) |

---

## Stopping the server

Press Ctrl+C in the terminal window.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| "Server not responding" in browser | Make sure `python server.py` is running and open http://localhost:8765 directly — do not open index.html as a file |
| "No granules found" | Try a different date or widen the time range. TEMPO only covers North America during daytime hours |
| Authentication error | Double-check .netrc spelling, no extra spaces, file is in your home directory |
| Packages missing | Re-run `pip install -r requirements.txt` |
| Port 8765 in use | Another server instance is running — close it, or change PORT = 8765 in server.py |

---

## Files included

| File | Purpose |
|---|---|
| `server.py` | Python HTTP server — fetches NASA data, serves JSON grids |
| `index.html` | Browser app — canvas rendering, animation, export |
| `requirements.txt` | Python package list |
| `Dockerfile` | Optional — run in Docker instead of installing Python locally |
| `docker-compose.yml` | Optional — Docker Compose configuration |
